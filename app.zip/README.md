# QuakeBot

QuakeBot is a lightweight Python harness for an LLM-controlled humanoid rescue robot in a symbolic, multi-floor earthquake-response world.

The robot is physically embodied: it follows sound and vibration cues, braces against rubble, lifts debris with powerful hands, reassures survivors, checks pulse/breathing/airway/bleeding, performs simplified primary surveys, stabilises people, and carries or escorts them to safety.

The core architecture is deliberately strict: the LLM never mutates world state. It receives structured observations and returns exactly one structured JSON action. The environment validates actions, applies state transitions, rejects unsafe/impossible moves, updates memory, and scores the mission.

## Why This Is a Strong LLM-Agent Harness

- Multi-floor symbolic environment with Ground, Floor 1, and Basement.
- Multiple survivors with different medical states and triage priorities.
- Progress-aware observations with blocked paths and recommended next actions.
- Mission-accounting layer that prevents early completion while survivors remain unverified.
- Humanoid rescue actions, including rubble removal and carrying people.
- Simplified medical checks: pulse, breathing, airway, bleeding, responsiveness, mobility, primary survey.
- Prioritisation logic for critical/high/medium/low survivors.
- Dynamic hazards: an aftershock makes Basement structurally severe and can block access.
- Optional OpenAI-compatible, local Ollama, and Ollama Cloud agents.
- Deterministic `MockAgent` demo works without an API key.

## World

Ground:
- Entrance
- Lobby
- Hallway
- Office
- Storage
- Stairwell_G

Floor 1:
- Stairwell_1
- Upper_Hallway
- Apartment_A
- Apartment_B
- Balcony

Basement:
- Stairwell_B
- Basement
- Utility_Room
- Generator_Room

The default survivors are:

- `survivor_office`: trapped under Office rubble, rapid pulse, fast breathing, minor bleeding, cannot walk.
- `survivor_apartment_a`: injured and frightened on Floor 1, stable, can walk with assistance.
- `survivor_basement`: critical cues below, laboured breathing, weak pulse, severe bleeding, dangerous basement access after aftershock.

## Observation Schema

Observations are JSON-serialisable and include:

- `current_floor`, `floor_name`, `vertical_exits`
- room exits, local conditions, visible objects
- heard sounds, vibration cues, survivor cues
- `local_survivors`
- `known_survivors`
- `mission_accounting`
- `blocked_paths`
- `recommended_next_actions`
- memory and recent events

Example:

```json
{
  "location": "Hallway",
  "current_floor": 0,
  "floor_name": "Ground",
  "visible_exits": ["Lobby", "Office", "Storage"],
  "blocked_paths": {
    "Office": {
      "reason": "rubble",
      "status": "approached",
      "required_location": "Hallway",
      "next_required_action": "lift_rubble"
    }
  },
  "recommended_next_actions": [
    {"type": "lift_rubble", "target": "Office"}
  ],
  "mission_accounting": {
    "total_known_or_suspected_survivors": 3,
    "evacuated": ["survivor_office"],
    "unaccounted": ["survivor_apartment_a", "survivor_basement"],
    "mission_can_finish": false,
    "reason_not_finished": "survivor_apartment_a, survivor_basement has not been evacuated, directly assessed with extraction requested, or confirmed inaccessible"
  }
}
```

## Mission Accounting

QuakeBot does not optimise for partial success. The environment tracks every known or suspected survivor until each one is accounted for.

A survivor is accounted for only when one of these is true:

- `evacuated == true`
- `accounting_status == "awaiting_specialised_extraction"` after direct assessment, stabilisation, and extraction request
- `inaccessible_confirmed == true` after QuakeBot physically attempted access or scanned the hazard area

Final reports are rejected while `mission_accounting.unaccounted` is non-empty. This prevents an LLM agent from hallucinating completion, reporting an unverified survivor condition, or stopping after rescuing only the easiest two people.

Survivor accounting statuses are explicit:

- `unknown`
- `suspected`
- `located`
- `directly_assessed`
- `evacuated`
- `awaiting_specialised_extraction`
- `inaccessible_confirmed`

Only `evacuated`, `awaiting_specialised_extraction`, and `inaccessible_confirmed` are final statuses.

## Action Space

Navigation and search:
- `look`
- `move(target)`
- `inspect(target)`
- `search_room`
- `search_floor`
- `listen_for_survivor`
- `sense_vibrations`
- `scan_for_life_signs`

Physical rescue:
- `approach_rubble(target)`
- `lift_rubble(target)`
- `remove_rubble(target)`
- `carry_survivor(target)`
- `assist_walk(target)`
- `escort_to_exit(target)`

Survivor interaction:
- `reassure_survivor(target, message)`
- `ask_medical_question(target, question)`

Medical checks and stabilisation:
- `perform_primary_survey(target)`
- `check_pulse(target)`
- `check_breathing(target)`
- `check_airway(target)`
- `check_bleeding(target)`
- `check_responsiveness(target)`
- `check_mobility(target)`
- `apply_pressure_bandage(target)`
- `position_for_breathing(target)`
- `monitor_vitals(target)`
- `stabilise_survivor(target)`
- `tag_triage_priority(target, priority)`
- `request_medical_evac(target, reason)`
- `request_specialised_extraction(target, reason)`

Mission actions:
- `pick_up(item)`
- `mark_hazard(hazard_type)`
- `mark_room_cleared(target)`
- `mark_survivor_inaccessible(target)`
- `call_rescue_team(location, reason)`
- `return_to_base`
- `submit_report(summary)`

## Demo

```bash
python3 -m quakebot.demo
```

Pause before each step:

```bash
python3 -m quakebot.demo --step
```

The deterministic demo rescues `survivor_office`, rescues `survivor_apartment_a`, then continues into the basement investigation instead of ending early. It scans from `Stairwell_B`, enters the damaged Basement, directly assesses `survivor_basement`, checks pulse/breathing/bleeding, stabilises severe bleeding and laboured breathing, requests specialised extraction because the survivor is trapped under severe structural risk, returns to Entrance, notifies rescue teams, and submits a survivor-specific final report only after all three survivors are accounted for.

## Visual Demo

Launch the Streamlit presentation layer:

```bash
streamlit run quakebot/app.py
```

The visual demo replays the same environment episode as a step-by-step interface. It shows:

- Next, previous, reset, end, and auto-play controls.
- Agent source selection: MockAgent, Ollama Cloud, local Ollama, or OpenAI-compatible.
- A floor-by-floor pixel-art tile map with a selector for Ground, Floor 1, and Basement.
- QuakeBot's current tile/room, including whether it is carrying a survivor.
- Survivor, evacuated survivor, item, stairs, door, rubble, blocked, and hazard sprites.
- Current action JSON, action description, and result.
- Survivor cards with pulse, breathing, bleeding, mobility, checks completed, priority, and evacuation state.
- Robot status: location, floor, battery, inventory, carrying state, score, and mission progress.
- Mission log and dialogue events.
- Mission accounting, including whether the mission can finish and which survivors remain unaccounted.
- A full terminal-style step transcript matching the text demo.

The UI is intentionally separate from the simulation. `quakebot/replay.py` runs the existing `QuakeBotEnv` and records serialisable `EpisodeStep` snapshots. `quakebot/layouts.py` defines static pixel-map room regions, doors, stairs, rubble, and item coordinates. `quakebot/app.py` only renders those snapshots and layouts, so presentation code does not own world state or rescue transitions.

To use Ollama Cloud in the visual UI:

```bash
export OLLAMA_API_KEY=...
streamlit run quakebot/app.py
```

Then choose `Ollama Cloud` in the sidebar, set a model such as `gpt-oss:20b`, and click `Generate Episode`.

To use local Ollama in the visual UI:

```bash
ollama pull llama3.1
ollama serve
streamlit run quakebot/app.py
```

Then choose `Local Ollama` in the sidebar.

## Optional LLM Agents

OpenAI-compatible:

```bash
export OPENAI_API_KEY=...
python3 -m quakebot.demo --openai
```

Local Ollama:

```bash
ollama pull llama3.1
ollama serve
python3 -m quakebot.demo --ollama
```

Ollama Cloud:

```bash
export OLLAMA_API_KEY=...
python3 -m quakebot.demo --ollama-cloud --ollama-model gpt-oss:20b
```

The parser attempts to extract the first JSON object from markdown-wrapped or prose-wrapped model output before treating a response as invalid.

## Tests

```bash
pytest
```

## Design Notes

This is not a medical advice tool. It is a simplified rescue simulation designed to show a clean LLM-agent harness for humanoid robotics: structured perception, structured actions, validation, stateful environment transitions, memory, dynamic hazards, and mission scoring.
