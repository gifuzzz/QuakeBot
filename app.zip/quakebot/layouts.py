"""Static pixel-map layouts for the QuakeBot replay UI.

These layouts are presentation-only. They map symbolic room names from the
environment to fixed tile regions so the Streamlit UI can render a replay
without owning or mutating simulation state.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RoomRegion:
    name: str
    x: int
    y: int
    width: int
    height: int

    @property
    def center(self) -> tuple[int, int]:
        return (self.x + self.width // 2, self.y + self.height // 2)


@dataclass(frozen=True)
class FloorLayout:
    name: str
    width: int
    height: int
    rooms: dict[str, RoomRegion]
    doors: tuple[tuple[int, int], ...]
    stairs: tuple[tuple[int, int], ...]
    rubble: dict[str, tuple[int, int]]
    items: dict[str, tuple[int, int]]


FLOOR_LAYOUTS: dict[str, FloorLayout] = {
    "Ground": FloorLayout(
        name="Ground",
        width=22,
        height=15,
        rooms={
            "Entrance": RoomRegion("Entrance", 1, 5, 4, 4),
            "Lobby": RoomRegion("Lobby", 6, 4, 5, 6),
            "Hallway": RoomRegion("Hallway", 12, 4, 4, 6),
            "Office": RoomRegion("Office", 17, 2, 4, 4),
            "Storage": RoomRegion("Storage", 17, 9, 4, 4),
            "Stairwell_G": RoomRegion("Stairwell_G", 6, 11, 5, 3),
        },
        doors=((5, 6), (11, 6), (16, 4), (16, 10), (8, 10)),
        stairs=((8, 12),),
        rubble={"Office": (16, 4)},
        items={"first_aid_kit": (19, 11)},
    ),
    "Floor 1": FloorLayout(
        name="Floor 1",
        width=22,
        height=15,
        rooms={
            "Stairwell_1": RoomRegion("Stairwell_1", 1, 6, 5, 3),
            "Upper_Hallway": RoomRegion("Upper_Hallway", 7, 5, 5, 5),
            "Apartment_A": RoomRegion("Apartment_A", 14, 2, 6, 4),
            "Apartment_B": RoomRegion("Apartment_B", 14, 8, 5, 4),
            "Balcony": RoomRegion("Balcony", 19, 8, 2, 4),
        },
        doors=((6, 7), (12, 5), (12, 9), (19, 10)),
        stairs=((3, 7),),
        rubble={},
        items={},
    ),
    "Basement": FloorLayout(
        name="Basement",
        width=22,
        height=15,
        rooms={
            "Stairwell_B": RoomRegion("Stairwell_B", 1, 6, 5, 3),
            "Basement": RoomRegion("Basement", 7, 4, 7, 7),
            "Utility_Room": RoomRegion("Utility_Room", 15, 2, 5, 4),
            "Generator_Room": RoomRegion("Generator_Room", 15, 9, 5, 4),
        },
        doors=((6, 7), (14, 4), (14, 10)),
        stairs=((3, 7),),
        rubble={},
        items={},
    ),
}


FLOOR_NAMES = ("Ground", "Floor 1", "Basement")
